#include "ClassAbility.h"

ClassAbility::ClassAbility(Unit* owner) : owner(owner) {};

ClassAbility::~ClassAbility() {};