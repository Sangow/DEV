#include "PriestState.h"

PriestState::PriestState() : HumanState(100, 1, 1) {};

PriestState::~PriestState() {};