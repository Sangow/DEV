<?php
    function arrayMin(&$array) {
        return min($array);
    }
?>