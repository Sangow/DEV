public class ToMuchFuel extends Exception {}
