public class OutOfInk extends Exception {}
