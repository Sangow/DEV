#ifndef DEMON_STATE_H
#define DEMON_STATE_H

#include <iostream>
#include "State.h"

class DemonState : public State {
    public:
        DemonState();
        ~DemonState();
};

#endif // DEMON_STATE_H