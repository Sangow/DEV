package IPv4Address;

public class IPAddressException extends Exception {
    public IPAddressException(String message) {
        super(message);
    }
}
