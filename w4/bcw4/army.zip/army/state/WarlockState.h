#ifndef WARLOCK_STATE_H
#define WARLOCK_STATE_H

#include <iostream>
#include "HumanState.h"

class WarlockState : public HumanState {
    public:
        WarlockState();
        ~WarlockState();
};

#endif //WARLOCK_STATE_H