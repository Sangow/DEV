#include "WarlockState.h"

WarlockState::WarlockState() : HumanState(80, 0.5, 0.5) {};

WarlockState::~WarlockState() {};