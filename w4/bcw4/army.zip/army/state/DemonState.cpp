#include "DemonState.h"

DemonState::DemonState() : State(50) {
    this->strength = 2;
    this->agility = 2;
};

DemonState::~DemonState() {};