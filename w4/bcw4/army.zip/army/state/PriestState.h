#ifndef PRIEST_STATE_H
#define PRIEST_STATE_H

#include <iostream>
#include "HumanState.h"

class PriestState : public HumanState {
    public:
        PriestState();
        ~PriestState();
};

#endif // PRIEST_STATE_H