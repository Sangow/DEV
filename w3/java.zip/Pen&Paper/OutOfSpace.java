public class OutOfSpace extends Exception {}
