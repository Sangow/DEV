<?php
    list($a, $b) = explode(' ', trim(fgets(STDIN)));

    echo max($a, $b) . PHP_EOL;
?>