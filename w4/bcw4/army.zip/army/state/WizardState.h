#ifndef WIZARD_STATE_H
#define WIZARD_STATE_H

#include <iostream>
#include "HumanState.h"

class WizardState : public HumanState {
    public:
        WizardState();
        ~WizardState();
};

#endif // WIZARD_STATE_H