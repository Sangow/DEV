#include "SoldierState.h"

SoldierState::SoldierState() : HumanState(120, 1, 1) {};

SoldierState::~SoldierState() {};