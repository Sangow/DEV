#include "RogueState.h"

RogueState::RogueState() : HumanState(75, 0.5, 1.5) {};

RogueState::~RogueState() {};