public class OutOfFuel extends Exception {}
