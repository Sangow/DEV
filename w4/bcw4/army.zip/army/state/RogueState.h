#ifndef ROGUE_STATE_H
#define ROGUE_STATE_H

#include <iostream>
#include "HumanState.h"

class RogueState : public HumanState {
    public:
        RogueState();
        ~RogueState();
};

#endif // ROGUE_STATE_H