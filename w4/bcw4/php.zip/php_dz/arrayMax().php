<?php
    function arrayMax(&$array) {
        return max($array);
    }
?>