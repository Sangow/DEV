public class UnitIsDead extends Exception {}
