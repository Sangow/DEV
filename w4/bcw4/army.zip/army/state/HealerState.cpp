#include "HealerState.h"

HealerState::HealerState() : HumanState(70, 0.5, 0.5) {};

HealerState::~HealerState() {};