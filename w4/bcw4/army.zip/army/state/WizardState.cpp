#include "WizardState.h"

WizardState::WizardState() : HumanState(95, 0.5, 0.5) {};

WizardState::~WizardState() {};

