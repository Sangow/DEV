<?php
    echo "Hello, Bender!" . PHP_EOL;
?>