<?php
    function arrayZeroFill(&$array, $size) {
        $array = array_fill(0, $size, 0);
    }
?>